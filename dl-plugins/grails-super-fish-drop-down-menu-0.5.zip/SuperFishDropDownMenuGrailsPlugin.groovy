class SuperFishDropDownMenuGrailsPlugin {
    // the plugin version
    def version = "0.5"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.1.1 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def author = "Jonathan Yanes"
    def authorEmail = "jonalyanes@gmail.com"
    def title = "SuperFish Drop Down Menu Plugin"
    def description = '''\\
This plugin is designed to give developers the ability to easily add a drop down menu to their project using the SuperFish library.  The drop down menu will provide similar functionality as the grails-ui plugin, however this plugin is designed to be more light weight.  In order to under views change index.gsp to the following:  <meta name="layout" content="main_super" />'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/SuperFishDropDownMenu+Plugin"

    def doWithSpring = {
        // TODO Implement runtime spring config (optional)
    }

    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)
    }

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional)
    }

    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
